import * as THREE from '../node_modules/three/build/three.module.js';

class SpaceExplorer {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        
        // 宇宙オブジェクト
        this.stars = [];
        this.planets = [];
        this.shootingStars = [];
        
        // インタラクション
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.selectedPlanet = null;
        this.isPaused = false;
        
        // 統計情報
        this.frameCount = 0;
        this.lastTime = 0;
        this.fps = 0;
        
        // アニメーション
        this.clock = new THREE.Clock();
        
        this.init();
    }
    
    init() {
        this.createScene();
        this.createCamera();
        this.createRenderer();
        this.createLights();
        this.createBackground();
        this.createStars();
        this.createPlanets();
        this.createShootingStars();
        this.setupEventListeners();
        this.animate();
        
        // ローディング完了
        document.getElementById('loading').style.display = 'none';
    }
    
    createScene() {
        this.scene = new THREE.Scene();
        
        // 深い宇宙の背景色（紫から青のグラデーション）
        this.scene.background = new THREE.Color(0x0a0a2e);
        
        // フォグで深度感を演出
        this.scene.fog = new THREE.Fog(0x0a0a2e, 1000, 10000);
    }
    
    createCamera() {
        this.camera = new THREE.PerspectiveCamera(
            75,
            window.innerWidth / window.innerHeight,
            0.1,
            50000
        );
        this.camera.position.set(0, 100, 500);
    }
    
    createRenderer() {
        this.renderer = new THREE.WebGLRenderer({ 
            antialias: true,
            alpha: true 
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        
        document.getElementById('canvas-container').appendChild(this.renderer.domElement);
    }
    
    createLights() {
        // 環境光（全体の基本照明）
        const ambientLight = new THREE.AmbientLight(0x404040, 0.3);
        this.scene.add(ambientLight);
        
        // 太陽光（メインの光源）
        const sunLight = new THREE.DirectionalLight(0xffffff, 1.5);
        sunLight.position.set(0, 0, 0);
        sunLight.castShadow = true;
        sunLight.shadow.mapSize.width = 2048;
        sunLight.shadow.mapSize.height = 2048;
        sunLight.shadow.camera.near = 0.5;
        sunLight.shadow.camera.far = 5000;
        this.scene.add(sunLight);
        
        // 星の光（ポイントライト）
        const starLight = new THREE.PointLight(0x88aaff, 0.5, 1000);
        starLight.position.set(200, 200, 200);
        this.scene.add(starLight);
    }
    
    createBackground() {
        // 宇宙の背景グラデーション
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const context = canvas.getContext('2d');
        
        // グラデーションを作成（深い紫から青へ）
        const gradient = context.createRadialGradient(256, 256, 0, 256, 256, 256);
        gradient.addColorStop(0, '#1a0033');
        gradient.addColorStop(0.5, '#000066');
        gradient.addColorStop(1, '#000033');
        
        context.fillStyle = gradient;
        context.fillRect(0, 0, 512, 512);
        
        const texture = new THREE.CanvasTexture(canvas);
        
        // 背景スフィア
        const sphereGeometry = new THREE.SphereGeometry(25000, 32, 32);
        const sphereMaterial = new THREE.MeshBasicMaterial({
            map: texture,
            side: THREE.BackSide
        });
        const backgroundSphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
        this.scene.add(backgroundSphere);
    }
    
    createStars() {
        const starCount = 5000;
        const starGeometry = new THREE.BufferGeometry();
        const starPositions = new Float32Array(starCount * 3);
        const starColors = new Float32Array(starCount * 3);
        const starSizes = new Float32Array(starCount);
        
        // 銀河系の螺旋構造パラメータ
        const galaxyRadius = 8000;
        const galaxyArms = 4;
        const galaxyThickness = 200;
        
        for (let i = 0; i < starCount; i++) {
            const i3 = i * 3;
            
            // 銀河系の螺旋構造を作成
            const angle = Math.random() * Math.PI * 2;
            const radius = Math.random() * galaxyRadius;
            const spiralAngle = angle + (radius / galaxyRadius) * galaxyArms * Math.PI;
            
            // 位置計算
            const x = Math.cos(spiralAngle) * radius + (Math.random() - 0.5) * 500;
            const y = (Math.random() - 0.5) * galaxyThickness;
            const z = Math.sin(spiralAngle) * radius + (Math.random() - 0.5) * 500;
            
            starPositions[i3] = x;
            starPositions[i3 + 1] = y;
            starPositions[i3 + 2] = z;
            
            // 星の色（青白から赤まで）
            const colorType = Math.random();
            if (colorType < 0.3) {
                // 青白い星
                starColors[i3] = 0.8 + Math.random() * 0.2;     // R
                starColors[i3 + 1] = 0.9 + Math.random() * 0.1; // G
                starColors[i3 + 2] = 1.0;                       // B
            } else if (colorType < 0.6) {
                // 白い星
                starColors[i3] = 0.9 + Math.random() * 0.1;     // R
                starColors[i3 + 1] = 0.9 + Math.random() * 0.1; // G
                starColors[i3 + 2] = 0.8 + Math.random() * 0.2; // B
            } else if (colorType < 0.8) {
                // 黄色い星
                starColors[i3] = 1.0;                           // R
                starColors[i3 + 1] = 0.8 + Math.random() * 0.2; // G
                starColors[i3 + 2] = 0.3 + Math.random() * 0.3; // B
            } else {
                // 赤い星
                starColors[i3] = 1.0;                           // R
                starColors[i3 + 1] = 0.3 + Math.random() * 0.3; // G
                starColors[i3 + 2] = 0.1 + Math.random() * 0.2; // B
            }
            
            // 星のサイズ（距離に応じて調整）
            const distance = Math.sqrt(x * x + y * y + z * z);
            starSizes[i] = Math.random() * 3 + 1 + (distance / galaxyRadius) * 2;
        }
        
        starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
        starGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
        starGeometry.setAttribute('size', new THREE.BufferAttribute(starSizes, 1));
        
        // 星のマテリアル
        const starMaterial = new THREE.ShaderMaterial({
            uniforms: {
                time: { value: 0.0 }
            },
            vertexShader: `
                attribute float size;
                attribute vec3 color;
                varying vec3 vColor;
                uniform float time;
                
                void main() {
                    vColor = color;
                    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                    
                    // 星の瞬き効果
                    float twinkle = sin(time * 2.0 + position.x * 0.01) * 0.3 + 0.7;
                    gl_PointSize = size * twinkle * (300.0 / -mvPosition.z);
                    gl_Position = projectionMatrix * mvPosition;
                }
            `,
            fragmentShader: `
                varying vec3 vColor;
                
                void main() {
                    float distance = length(gl_PointCoord - vec2(0.5));
                    if (distance > 0.5) discard;
                    
                    float alpha = 1.0 - distance * 2.0;
                    alpha = pow(alpha, 2.0);
                    
                    gl_FragColor = vec4(vColor, alpha);
                }
            `,
            blending: THREE.AdditiveBlending,
            depthTest: false,
            transparent: true,
            vertexColors: true
        });
        
        const stars = new THREE.Points(starGeometry, starMaterial);
        this.scene.add(stars);
        this.stars.push(stars);
        
        // 遠くの星雲効果
        this.createNebula();
    }
    
    createNebula() {
        const nebulaCount = 50;
        
        for (let i = 0; i < nebulaCount; i++) {
            const nebulaGeometry = new THREE.PlaneGeometry(200 + Math.random() * 300, 200 + Math.random() * 300);
            const nebulaMaterial = new THREE.MeshBasicMaterial({
                color: new THREE.Color().setHSL(Math.random() * 0.3 + 0.6, 0.5, 0.3),
                transparent: true,
                opacity: 0.1 + Math.random() * 0.2,
                blending: THREE.AdditiveBlending,
                side: THREE.DoubleSide
            });
            
            const nebula = new THREE.Mesh(nebulaGeometry, nebulaMaterial);
            
            // ランダムな位置に配置
            const angle = Math.random() * Math.PI * 2;
            const radius = 3000 + Math.random() * 5000;
            nebula.position.x = Math.cos(angle) * radius;
            nebula.position.y = (Math.random() - 0.5) * 1000;
            nebula.position.z = Math.sin(angle) * radius;
            
            // ランダムな回転
            nebula.rotation.x = Math.random() * Math.PI;
            nebula.rotation.y = Math.random() * Math.PI;
            nebula.rotation.z = Math.random() * Math.PI;
            
            this.scene.add(nebula);
        }
    }
    
    createPlanets() {
        // 太陽を作成
        this.createSun();
        
        // 惑星データ
        const planetData = [
            {
                name: '水星',
                type: '岩石惑星',
                radius: 8,
                distance: 120,
                speed: 0.02,
                color: 0x8c7853,
                description: '太陽に最も近い惑星。表面温度は昼間430°C、夜間-170°C。',
                size: '地球の0.38倍'
            },
            {
                name: '金星',
                type: '岩石惑星',
                radius: 12,
                distance: 180,
                speed: 0.015,
                color: 0xffc649,
                description: '最も高温の惑星。厚い大気により温室効果で表面温度は460°C。',
                size: '地球の0.95倍'
            },
            {
                name: '地球',
                type: '岩石惑星',
                radius: 15,
                distance: 250,
                speed: 0.01,
                color: 0x6b93d6,
                description: '生命が存在する唯一の惑星。表面の71%が海で覆われている。',
                size: '基準サイズ'
            },
            {
                name: '火星',
                type: '岩石惑星',
                radius: 10,
                distance: 320,
                speed: 0.008,
                color: 0xcd5c5c,
                description: '赤い惑星として知られる。極地には氷が存在し、過去に水が流れていた。',
                size: '地球の0.53倍'
            },
            {
                name: '木星',
                type: 'ガス巨星',
                radius: 35,
                distance: 450,
                speed: 0.005,
                color: 0xd8ca9d,
                description: '太陽系最大の惑星。大赤斑という巨大な嵐が特徴。79個の衛星を持つ。',
                size: '地球の11.2倍'
            },
            {
                name: '土星',
                type: 'ガス巨星',
                radius: 30,
                distance: 550,
                speed: 0.004,
                color: 0xfad5a5,
                description: '美しい環を持つ惑星。密度が水より軽い。82個の衛星を持つ。',
                size: '地球の9.4倍'
            },
            {
                name: '天王星',
                type: '氷巨星',
                radius: 20,
                distance: 650,
                speed: 0.003,
                color: 0x4fd0e7,
                description: '横倒しに自転する惑星。メタンにより青緑色に見える。27個の衛星を持つ。',
                size: '地球の4.0倍'
            },
            {
                name: '海王星',
                type: '氷巨星',
                radius: 18,
                distance: 750,
                speed: 0.002,
                color: 0x4b70dd,
                description: '太陽系で最も風速が速い惑星。時速2100kmの風が吹く。14個の衛星を持つ。',
                size: '地球の3.9倍'
            }
        ];
        
        planetData.forEach((data, index) => {
            this.createPlanet(data, index);
        });
    }
    
    createSun() {
        const sunGeometry = new THREE.SphereGeometry(50, 32, 32);
        const sunMaterial = new THREE.ShaderMaterial({
            uniforms: {
                time: { value: 0.0 }
            },
            vertexShader: `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform float time;
                varying vec2 vUv;
                
                void main() {
                    vec2 center = vec2(0.5, 0.5);
                    float dist = distance(vUv, center);
                    
                    // 太陽の表面の動き
                    float noise = sin(vUv.x * 10.0 + time) * sin(vUv.y * 10.0 + time * 0.5) * 0.1;
                    float intensity = 1.0 - dist + noise;
                    
                    vec3 color = vec3(1.0, 0.6, 0.1) * intensity;
                    gl_FragColor = vec4(color, 1.0);
                }
            `
        });
        
        const sun = new THREE.Mesh(sunGeometry, sunMaterial);
        sun.position.set(0, 0, 0);
        
        // 太陽の光
        const sunLight = new THREE.PointLight(0xffffff, 2, 2000);
        sunLight.position.copy(sun.position);
        this.scene.add(sunLight);
        
        // 太陽のコロナ効果
        const coronaGeometry = new THREE.SphereGeometry(60, 32, 32);
        const coronaMaterial = new THREE.MeshBasicMaterial({
            color: 0xffaa00,
            transparent: true,
            opacity: 0.3,
            blending: THREE.AdditiveBlending
        });
        const corona = new THREE.Mesh(coronaGeometry, coronaMaterial);
        corona.position.copy(sun.position);
        
        this.scene.add(sun);
        this.scene.add(corona);
        
        // 太陽のアニメーション用データ
        sun.userData = { 
            type: 'sun',
            material: sunMaterial,
            corona: corona
        };
        this.planets.push(sun);
    }
    
    createPlanet(data, index) {
        const planetGeometry = new THREE.SphereGeometry(data.radius, 32, 32);
        const planetMaterial = new THREE.MeshPhongMaterial({
            color: data.color,
            shininess: 30
        });
        
        const planet = new THREE.Mesh(planetGeometry, planetMaterial);
        
        // 初期位置
        planet.position.x = data.distance;
        planet.position.y = 0;
        planet.position.z = 0;
        
        // 惑星のデータを保存
        planet.userData = {
            name: data.name,
            type: data.type,
            distance: data.distance + 'AU',
            size: data.size,
            description: data.description,
            orbitDistance: data.distance,
            orbitSpeed: data.speed,
            angle: Math.random() * Math.PI * 2, // 初期角度をランダムに
            rotationSpeed: 0.01 + Math.random() * 0.02
        };
        
        // 軌道線を作成
        this.createOrbitLine(data.distance);
        
        // 惑星に特別な効果を追加
        if (data.name === '地球') {
            this.addEarthEffects(planet);
        } else if (data.name === '土星') {
            this.addSaturnRings(planet);
        }
        
        this.scene.add(planet);
        this.planets.push(planet);
    }
    
    createOrbitLine(distance) {
        const orbitGeometry = new THREE.RingGeometry(distance - 1, distance + 1, 64);
        const orbitMaterial = new THREE.MeshBasicMaterial({
            color: 0x444444,
            transparent: true,
            opacity: 0.2,
            side: THREE.DoubleSide
        });
        
        const orbit = new THREE.Mesh(orbitGeometry, orbitMaterial);
        orbit.rotation.x = Math.PI / 2;
        this.scene.add(orbit);
    }
    
    addEarthEffects(earth) {
        // 地球の雲
        const cloudGeometry = new THREE.SphereGeometry(earth.geometry.parameters.radius + 2, 32, 32);
        const cloudMaterial = new THREE.MeshBasicMaterial({
            color: 0xffffff,
            transparent: true,
            opacity: 0.3,
            blending: THREE.AdditiveBlending
        });
        
        const clouds = new THREE.Mesh(cloudGeometry, cloudMaterial);
        clouds.position.copy(earth.position);
        earth.add(clouds);
        
        earth.userData.clouds = clouds;
    }
    
    addSaturnRings(saturn) {
        const ringGeometry = new THREE.RingGeometry(
            saturn.geometry.parameters.radius + 5,
            saturn.geometry.parameters.radius + 15,
            32
        );
        const ringMaterial = new THREE.MeshBasicMaterial({
            color: 0xcccccc,
            transparent: true,
            opacity: 0.7,
            side: THREE.DoubleSide
        });
        
        const rings = new THREE.Mesh(ringGeometry, ringMaterial);
        rings.rotation.x = Math.PI / 2 + 0.2; // 少し傾ける
        saturn.add(rings);
        
        saturn.userData.rings = rings;
    }
    
    createShootingStars() {
        // 流れ星の初期化
        this.shootingStarTimer = 0;
        this.shootingStarInterval = 3 + Math.random() * 5; // 3-8秒間隔
    }
    
    createShootingStar() {
        const shootingStarGeometry = new THREE.BufferGeometry();
        const positions = new Float32Array(100 * 3); // 100個の点で軌跡を作成
        const colors = new Float32Array(100 * 3);
        
        // 流れ星の開始位置（画面外から）
        const startDistance = 2000 + Math.random() * 1000;
        const angle = Math.random() * Math.PI * 2;
        const height = (Math.random() - 0.5) * 500;
        
        const startX = Math.cos(angle) * startDistance;
        const startY = height;
        const startZ = Math.sin(angle) * startDistance;
        
        // 流れ星の方向（中心に向かう）
        const direction = new THREE.Vector3(-startX, -startY, -startZ).normalize();
        
        // 軌跡の初期化
        for (let i = 0; i < 100; i++) {
            const i3 = i * 3;
            positions[i3] = startX;
            positions[i3 + 1] = startY;
            positions[i3 + 2] = startZ;
            
            // 色（白から透明へ）
            const alpha = 1 - (i / 100);
            colors[i3] = 1.0;     // R
            colors[i3 + 1] = 1.0; // G
            colors[i3 + 2] = 1.0; // B
        }
        
        shootingStarGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        shootingStarGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        
        const shootingStarMaterial = new THREE.LineBasicMaterial({
            vertexColors: true,
            transparent: true,
            opacity: 0.8,
            blending: THREE.AdditiveBlending
        });
        
        const shootingStar = new THREE.Line(shootingStarGeometry, shootingStarMaterial);
        
        // 流れ星のデータ
        shootingStar.userData = {
            startPosition: new THREE.Vector3(startX, startY, startZ),
            direction: direction,
            speed: 800 + Math.random() * 400, // 800-1200の速度
            life: 0,
            maxLife: 2 + Math.random() * 2, // 2-4秒の寿命
            trail: []
        };
        
        this.scene.add(shootingStar);
        this.shootingStars.push(shootingStar);
    }
    
    setupEventListeners() {
        // ウィンドウリサイズ
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
        
        // マウス操作
        this.setupMouseControls();
        
        // キーボード操作
        document.addEventListener('keydown', (event) => {
            switch(event.key) {
                case 'Escape':
                    this.resetCamera();
                    break;
                case ' ':
                    event.preventDefault();
                    this.togglePause();
                    break;
                case 'r':
                case 'R':
                    this.randomViewpoint();
                    break;
                case 'h':
                case 'H':
                    this.toggleUI();
                    break;
            }
        });
    }
    
    setupMouseControls() {
        let isDragging = false;
        let previousMousePosition = { x: 0, y: 0 };
        
        // マウスドラッグで視点変更
        this.renderer.domElement.addEventListener('mousedown', (event) => {
            isDragging = true;
            previousMousePosition = { x: event.clientX, y: event.clientY };
        });
        
        this.renderer.domElement.addEventListener('mousemove', (event) => {
            if (isDragging) {
                const deltaMove = {
                    x: event.clientX - previousMousePosition.x,
                    y: event.clientY - previousMousePosition.y
                };
                
                // Shiftキーで高速回転
                const rotationSpeed = event.shiftKey ? 0.01 : 0.005;
                
                // カメラを中心点の周りで回転
                const spherical = new THREE.Spherical();
                spherical.setFromVector3(this.camera.position);
                
                spherical.theta -= deltaMove.x * rotationSpeed;
                spherical.phi += deltaMove.y * rotationSpeed;
                
                // phi の範囲を制限
                spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, spherical.phi));
                
                this.camera.position.setFromSpherical(spherical);
                this.camera.lookAt(0, 0, 0);
                
                previousMousePosition = { x: event.clientX, y: event.clientY };
            }
        });
        
        this.renderer.domElement.addEventListener('mouseup', () => {
            isDragging = false;
        });
        
        // ホイールでズーム
        this.renderer.domElement.addEventListener('wheel', (event) => {
            event.preventDefault();
            
            // Ctrlキーで精密ズーム
            const zoomSpeed = event.ctrlKey ? 0.02 : 0.1;
            const direction = event.deltaY > 0 ? 1 : -1;
            
            const distance = this.camera.position.length();
            const newDistance = Math.max(50, Math.min(5000, distance + direction * distance * zoomSpeed));
            
            this.camera.position.normalize().multiplyScalar(newDistance);
        });
        
        // 惑星クリック
        this.renderer.domElement.addEventListener('click', (event) => {
            this.onPlanetClick(event);
        });
    }
    
    onPlanetClick(event) {
        // マウス座標を正規化
        this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        this.mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
        
        // レイキャスティング
        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.planets);
        
        if (intersects.length > 0) {
            const planet = intersects[0].object;
            this.focusOnPlanet(planet);
        }
    }
    
    focusOnPlanet(planet) {
        this.selectedPlanet = planet;
        
        // 惑星情報を表示
        this.showPlanetInfo(planet);
        
        // カメラを惑星に向ける
        const targetPosition = planet.position.clone();
        targetPosition.add(new THREE.Vector3(0, 0, planet.geometry.parameters.radius * 3));
        
        // スムーズなカメラ移動
        this.animateCamera(targetPosition, planet.position);
    }
    
    showPlanetInfo(planet) {
        const infoPanel = document.getElementById('planet-info');
        const planetData = planet.userData;
        
        document.getElementById('planet-name').textContent = planetData.name;
        document.getElementById('planet-type').textContent = `種類: ${planetData.type}`;
        document.getElementById('planet-distance').textContent = `太陽からの距離: ${planetData.distance}`;
        document.getElementById('planet-size').textContent = `サイズ: ${planetData.size}`;
        document.getElementById('planet-description').textContent = planetData.description;
        
        infoPanel.style.display = 'block';
        
        // 5秒後に自動で非表示
        setTimeout(() => {
            infoPanel.style.display = 'none';
        }, 5000);
    }
    
    animateCamera(targetPosition, lookAtPosition) {
        const startPosition = this.camera.position.clone();
        const duration = 2000; // 2秒
        const startTime = Date.now();
        
        const animateStep = () => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // イージング関数
            const easeProgress = 1 - Math.pow(1 - progress, 3);
            
            this.camera.position.lerpVectors(startPosition, targetPosition, easeProgress);
            this.camera.lookAt(lookAtPosition);
            
            if (progress < 1) {
                requestAnimationFrame(animateStep);
            }
        };
        
        animateStep();
    }
    
    resetCamera() {
        this.camera.position.set(0, 100, 500);
        this.camera.lookAt(0, 0, 0);
        document.getElementById('planet-info').style.display = 'none';
    }
    
    togglePause() {
        this.isPaused = !this.isPaused;
        if (this.isPaused) {
            this.clock.stop();
        } else {
            this.clock.start();
        }
    }
    
    randomViewpoint() {
        const distance = 200 + Math.random() * 800;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        
        this.camera.position.setFromSphericalCoords(distance, phi, theta);
        this.camera.lookAt(0, 0, 0);
    }
    
    toggleUI() {
        const panels = ['info-panel', 'controls-panel', 'stats-panel'];
        panels.forEach(panelId => {
            const panel = document.getElementById(panelId);
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        });
    }
    
    updateStats() {
        this.frameCount++;
        const currentTime = performance.now();
        
        if (currentTime - this.lastTime >= 1000) {
            this.fps = Math.round((this.frameCount * 1000) / (currentTime - this.lastTime));
            this.frameCount = 0;
            this.lastTime = currentTime;
            
            // UI更新
            document.getElementById('fps-counter').textContent = `FPS: ${this.fps}`;
            document.getElementById('object-count').textContent = `オブジェクト: ${this.scene.children.length}`;
            
            const camPos = this.camera.position;
            document.getElementById('camera-position').textContent = 
                `カメラ: (${Math.round(camPos.x)}, ${Math.round(camPos.y)}, ${Math.round(camPos.z)})`;
            
            document.getElementById('shooting-stars-count').textContent = `流れ星: ${this.shootingStars.length}`;
        }
    }
    
    animate() {
        requestAnimationFrame(() => this.animate());
        
        // 統計情報を更新
        this.updateStats();
        
        if (!this.isPaused) {
            const deltaTime = this.clock.getDelta();
            const elapsedTime = this.clock.getElapsedTime();
            
            // 星の瞬き効果を更新
            this.updateStars(elapsedTime);
            
            // ここで各オブジェクトのアニメーションを更新
            this.updatePlanets(deltaTime);
            this.updateShootingStars(deltaTime);
        }
        
        this.renderer.render(this.scene, this.camera);
    }
    
    updateStars(elapsedTime) {
        this.stars.forEach(starSystem => {
            if (starSystem.material.uniforms && starSystem.material.uniforms.time) {
                starSystem.material.uniforms.time.value = elapsedTime;
            }
        });
    }
    
    updatePlanets(deltaTime) {
        this.planets.forEach(planet => {
            if (planet.userData.type === 'sun') {
                // 太陽のアニメーション
                if (planet.userData.material && planet.userData.material.uniforms) {
                    planet.userData.material.uniforms.time.value += deltaTime;
                }
                
                // コロナの回転
                if (planet.userData.corona) {
                    planet.userData.corona.rotation.z += deltaTime * 0.1;
                }
            } else if (planet.userData.orbitDistance) {
                // 惑星の軌道運動
                planet.userData.angle += planet.userData.orbitSpeed * deltaTime;
                
                const x = Math.cos(planet.userData.angle) * planet.userData.orbitDistance;
                const z = Math.sin(planet.userData.angle) * planet.userData.orbitDistance;
                
                planet.position.x = x;
                planet.position.z = z;
                
                // 惑星の自転
                planet.rotation.y += planet.userData.rotationSpeed * deltaTime;
                
                // 地球の雲の回転
                if (planet.userData.clouds) {
                    planet.userData.clouds.rotation.y += planet.userData.rotationSpeed * deltaTime * 0.8;
                }
                
                // 土星の環の回転
                if (planet.userData.rings) {
                    planet.userData.rings.rotation.z += planet.userData.rotationSpeed * deltaTime * 0.5;
                }
            }
        });
    }
    
    updateShootingStars(deltaTime) {
        // 新しい流れ星の生成タイミング
        this.shootingStarTimer += deltaTime;
        if (this.shootingStarTimer >= this.shootingStarInterval) {
            this.createShootingStar();
            this.shootingStarTimer = 0;
            this.shootingStarInterval = 3 + Math.random() * 5; // 次の間隔をリセット
        }
        
        // 既存の流れ星の更新
        for (let i = this.shootingStars.length - 1; i >= 0; i--) {
            const shootingStar = this.shootingStars[i];
            const userData = shootingStar.userData;
            
            userData.life += deltaTime;
            
            if (userData.life >= userData.maxLife) {
                // 寿命が尽きた流れ星を削除
                this.scene.remove(shootingStar);
                this.shootingStars.splice(i, 1);
                continue;
            }
            
            // 流れ星の位置を更新
            const currentPosition = userData.startPosition.clone();
            currentPosition.add(userData.direction.clone().multiplyScalar(userData.speed * userData.life));
            
            // 軌跡を更新
            userData.trail.push(currentPosition.clone());
            if (userData.trail.length > 20) {
                userData.trail.shift(); // 古い位置を削除
            }
            
            // ジオメトリを更新
            const positions = shootingStar.geometry.attributes.position.array;
            const colors = shootingStar.geometry.attributes.color.array;
            
            for (let j = 0; j < userData.trail.length; j++) {
                const j3 = j * 3;
                const trailPosition = userData.trail[j];
                
                positions[j3] = trailPosition.x;
                positions[j3 + 1] = trailPosition.y;
                positions[j3 + 2] = trailPosition.z;
                
                // 軌跡の色（先端が明るく、後ろが暗く）
                const alpha = j / userData.trail.length;
                colors[j3] = alpha;     // R
                colors[j3 + 1] = alpha; // G
                colors[j3 + 2] = alpha; // B
            }
            
            // 残りの点を非表示にする
            for (let j = userData.trail.length; j < 100; j++) {
                const j3 = j * 3;
                positions[j3] = currentPosition.x;
                positions[j3 + 1] = currentPosition.y;
                positions[j3 + 2] = currentPosition.z;
                
                colors[j3] = 0;
                colors[j3 + 1] = 0;
                colors[j3 + 2] = 0;
            }
            
            shootingStar.geometry.attributes.position.needsUpdate = true;
            shootingStar.geometry.attributes.color.needsUpdate = true;
            
            // フェードアウト効果
            const fadeProgress = userData.life / userData.maxLife;
            shootingStar.material.opacity = 0.8 * (1 - fadeProgress);
        }
    }
}

// アプリケーション開始
window.addEventListener('DOMContentLoaded', () => {
    new SpaceExplorer();
});

